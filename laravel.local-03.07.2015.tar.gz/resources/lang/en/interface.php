<?php
    return [
        'welcome' => 'Welcome!',
        'rememberMe' => 'Remember Me',
        'password' => 'Password',
        'login' => 'Login',
        'logo' => 'Logo',
        'auth' => 'Auth',
        'errorUser' => 'Wrong login or password'
    ]
?>