<div id="header">
    <div class="logo">
        <a href="#">{{ trans('interface.logo') }}</a>
    </div>
    <div class="change-lang">
        <a href="/lang/ru"><img src="/images/lang/ru.png" alt="Руссий"/></a>
        <a href="/lang/en"><img src="/images/lang/en.png" alt="English"/></a>
    </div>
</div>