@extends('start')

@section('title', trans('interface.auth'))