<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>@yield('title')</title>
    <!-- Main styles -->
    <link rel="stylesheet" href="styles/main.css"/>
    <link rel="stylesheet" href="styles/reset.css"/>
    <!-- Evil icons -->
    <link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/evil-icons/1.7.2/evil-icons.min.css">
    <script src="//cdnjs.cloudflare.com/ajax/libs/evil-icons/1.7.2/evil-icons.min.js"></script>
</head>
<body>
    <div class="change-lang">
        <div data-icon="ei-spinner-3" data-size="s"></div>
        <a href="lang/ru">Русский</a>
        <a href="lang/en">English</a>
    </div>
    <div class="header">
        @section('header')

        @show
    </div>
</body>
</html>