<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>@yield('title', trans('interface.welcome'))</title>
    <!-- Main styles -->
    <link rel="stylesheet" href="/styles/reset.css"/>
    <link rel="stylesheet" href="/styles/main.css"/>
    <!-- Evil icons -->
    <link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/evil-icons/1.7.2/evil-icons.min.css">
    <script src="//cdnjs.cloudflare.com/ajax/libs/evil-icons/1.7.2/evil-icons.min.js"></script>
</head>
<body>
    <!-- top-line -->
    <div id="top-line"></div>
    <!-- header -->
    @include('templates.header')
    <!-- Login form -->
    @include('templates.login')
</body>
</html>