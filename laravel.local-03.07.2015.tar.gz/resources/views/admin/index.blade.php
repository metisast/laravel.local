@extends('app')

@section('title', trans('interface.welcome'))